// src/pages/UrlBook/store.ts
import create from 'zustand';
import { v4 as uuidv4 } from 'uuid';
import { fetchUrls, UrlData } from 'src/apis/urlDummy';
import { useEffect } from 'react';

export interface UrlItem {
  id: string;
  checked: boolean;
  url: string; 
}

interface UrlStore {
  urls: UrlItem[];
  toggleCheck: (id: string) => void;
  addUrl: (newUrl: { url: string }) => void; // Modify the type of newUrl parameter
  deleteCheckedUrls: () => void;
}

export const useUrlStore = create<UrlStore>((set) => ({
  urls: [],
  toggleCheck: (id: string) => {
    set((state) => ({
      urls: state.urls.map((url) =>
        url.id === id ? { ...url, checked: !url.checked } : url
      ),
    }));
  },
  addUrl: (newUrl: { url: string }) => { // Modify the type of newUrl parameter
    set((state) => ({
      urls: [...state.urls, { ...newUrl, id: uuidv4(), checked: false }], // Add the checked field
    }));
  },
  addUrls: (newUrl: { url: string }) => { // Modify the type of newUrl parameter
    set((state) => ({
      urls: [...state.urls, { ...newUrl, id: uuidv4(), checked: false }], // Add the checked field
    }));
  },
  deleteCheckedUrls: () => {
    set((state) => ({
      urls: state.urls.filter((url) => !url.checked),
    }));
  },
}));

// 더미 데이터를 가져와서 store에 추가하는 코드
// useEffect를 사용하여 컴포넌트가 렌더링될 때 한 번만 실행됩니다.
export const useFetchDummyUrls = () => {
  console.log('useFetchDummyUrls 함수가 실행되었습니다.');
  const fetchData = async () => {
    try {
      const data = await fetchUrls(); // 더미 데이터 가져오기
      console.log(data)
      console.log('fetchUrls를 두번하나 ?')
      data.forEach((item: UrlData) => {
        useUrlStore.getState().addUrl({ url: item.url }); // store에 데이터 추가
      });
    } catch (error) {
      console.error('Error fetching URLs:', error);
    }
  };
  useEffect(() => {
  fetchData();
  }, []); // useEffect의 두 번째 인자로 빈 배열을 전달하여 컴포넌트가 처음 렌더링될 때만 실행되도록 합니다.
};
