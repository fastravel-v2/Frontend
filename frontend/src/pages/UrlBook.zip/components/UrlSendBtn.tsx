
export const UrlSendBtn = () => {
  return (
    <div>UrlSend버튼</div>
  )
}
