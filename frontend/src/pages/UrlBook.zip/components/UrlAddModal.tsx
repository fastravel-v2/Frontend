// src/pages/UrlBook/components/AddUrlModal.tsx
import React, { useState, useRef, useEffect } from 'react'; // useRef, useEffect 추가
import { useUrlStore } from '../store';
import { v4 as uuidv4 } from 'uuid';

const UrlAddModal: React.FC<{ doCloseModal: () => void }> = ({ doCloseModal }) => {
  // const [memo, setMemo] = useState('');
  const [url, setUrl] = useState(''); // Add this line
  const addUrl = useUrlStore((state) => state.addUrl);

  const urlInputRef = useRef<HTMLTextAreaElement>(null); // textarea 엘리먼트에 대한 참조 생성

  useEffect(() => {
    // 모달이 열릴 때 포커스를 메모 입력창으로 이동
    if (urlInputRef.current) {
      urlInputRef.current.focus();
    }
  }, []); // []로 빈 배열을 전달하여 한 번만 실행되도록 설정

  const handleSubmit = () => {
    const newUrl = {
      id: uuidv4(),
      thumbnail: 'https://cdn.myro.co.kr/prod/image/city/Busan.jpg', // Placeholder thumbnail
      memo: 'memo',
      title: `Title of URL`, // Placeholder title
      plot: 'Plot of URL', // Placeholder <plot></plot>
      checked: false,
      url: url, // Use the url state
    };
    addUrl(newUrl);
    
    // if (urlInputRef.current) {
    //   urlInputRef.current.blur(); // Focus 제거로 가상 키보드 숨김
    // }

  // setTimeout을 사용하기 전에 current 값을 임시 변수에 저장
    const currentInputRef = urlInputRef.current;
    
    if (currentInputRef) {
      setTimeout(() => {
        // 여기에서는 currentInputRef가 null이 아님을 이미 확인했기 때문에
        // TypeScript 에러를 피할 수 있음
        currentInputRef.blur();
      }, 0);
    }
    
    

    doCloseModal(); // props로 받은 closeModal 실행해서 닫음


  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };
  

  return (
    <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full">
      <div className="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div className="mt-3 text-center">
          <h3 className="text-lg leading-6 font-medium text-gray-900">URL 입력</h3>
          <div className="mt-2 px-7 py-3">
            {/* <textarea
              className="resize-none border rounded-md w-72 text-center"
              placeholder="입력"
              rows={1}
              onChange={(e) => setMemo(e.target.value)}
              ></textarea> */}
            <textarea
              ref={urlInputRef} // 여길 여행 리스트로 바꿔야겠엉
              className="resize-none border rounded-md w-72 mt-2 text-center"
              placeholder="URL 입력"
              value={url}
              onKeyDown={handleKeyDown}
              rows={1}
              onChange={(e) => setUrl(e.target.value)}
            />
          </div>

          <div className='flex justify-center'>
            <div className="items-center px-4 py-3">
              <button
                className="px-4 py-2 bg-green-700 text-white text-base 
                  font-medium rounded-md w-full shadow-sm hover:bg-blue-700 
                  focus:outline-none focus:ring-2 focus:ring-blue-300"
                onClick={handleSubmit}
              >
                Add
              </button>
            </div>

            <div className="items-center px-4 py-3">
              <button
                className="px-4 py-2 bg-white text-base 
                font-medium rounded-md w-full shadow-sm hover:bg-gray-100 
                focus:outline-none focus:ring-2 focus:ring-blue-300"
                onClick={doCloseModal}
              >
                Cancel
              </button>
            </div>

          </div>

        </div>
      </div>
    </div>
  );
};

export default UrlAddModal;
